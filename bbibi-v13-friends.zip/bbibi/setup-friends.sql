-- 삐삐 친구 기능 추가
create table if not exists public.friends (
  user_id uuid not null references auth.users(id) on delete cascade,
  friend_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id),
  check (user_id <> friend_id)
);

alter table public.friends enable row level security;

drop policy if exists "friends_authenticated" on public.friends;
create policy "friends_authenticated"
on public.friends for all
to authenticated
using (true)
with check (true);

-- 개발 버전에서는 가입된 번호로 친구를 찾기 위해 profiles 조회를 허용합니다.
-- 출시 전에는 전화번호 직접 노출 대신 RPC/해시 검색 방식으로 강화하세요.
